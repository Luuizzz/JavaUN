/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ligab;

/**
 *
 * @author juluc
 */
public class LigaB {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       equipo frame = new equipo();
       frame.setVisible(true);
     //  frame.setLocationRelativeTo(null); 
    //   frame.setSize(700, 600);
      frame.setResizable(false); 
       
       String nombreCompleto="Katherine Ospino";
String apellido = nombreCompleto.substring(10);
System.out.println(apellido);

        String s1="si lo que vas a decir no es mas bello que el silencio: no lo digas";
        String s2="para el que cree no es necesaria ninguna explicacion:para el que no cree toda explicacion sobra";
        String s3="El sabio no dice todo lo que piensa, pero siempre piensa todo lo que dice";
       String s4=(s2.substring(67, 75)+s3.substring(23, 36));
        System.out.println(s4);
       int A= ((s1.substring(56).length()));
        System.out.println(A);
        System.out.println(s1.length());
        String s5=(s2.substring(34, 53)+s2.substring(91,90+ (s1.substring(61)).length())     );
        System.out.println(s5);
        System.out.println("4.");
        String p1="El sabio";
        String p2="cree";
        String p3= "que";
        String p4="el silencio";
        String p5="es mas bello";
        String p6="no lo digas";
        String p7="siempre piensa";
        
        
        
        System.out.println( (s3.substring(0,9))+("")+("")  );
        
        
        
        // substr length equals compareto 
        //ya vistos:replace. 
       
       
       
       
    }
    
}
